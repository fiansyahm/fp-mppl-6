-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table siekihproker.evaluasis
DROP TABLE IF EXISTS `evaluasis`;
CREATE TABLE IF NOT EXISTS `evaluasis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `unit_id` bigint(20) unsigned NOT NULL,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `dokumen` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `komentar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `evaluasis_unit_id_foreign` (`unit_id`),
  CONSTRAINT `evaluasis_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table siekihproker.evaluasis: ~23 rows (approximately)
/*!40000 ALTER TABLE `evaluasis` DISABLE KEYS */;
REPLACE INTO `evaluasis` (`id`, `unit_id`, `judul`, `status`, `dokumen`, `komentar`, `tanggal`) VALUES
	(1, 3, 'Quae sit quia nemo.', -1, NULL, NULL, '2021-12-07'),
	(2, 5, 'Qui quaerat et.', 1, NULL, NULL, '2021-12-07'),
	(3, 4, 'Porro voluptas eius.', -1, NULL, NULL, '2021-12-07'),
	(4, 5, 'Aut eum.', 1, NULL, 'agajjkgrejkg', '2021-12-07'),
	(7, 4, 'Et aut aut quia.', -1, NULL, NULL, '2021-12-07'),
	(8, 2, 'Ut et repudiandae.', 1, NULL, NULL, '2021-12-07'),
	(9, 3, 'Eligendi earum odio.', -1, NULL, 'asdasdasdas', '2021-12-07'),
	(10, 4, 'Quia error quidem.', 1, NULL, 'hgkfhkfkgyuk', '2021-12-07'),
	(11, 5, 'Nam nihil unde.', -1, NULL, 'komentar', '2021-12-07'),
	(12, 2, 'Dolorum voluptatem.', -1, NULL, NULL, '2021-12-07'),
	(13, 3, 'Accusamus nisi.', 1, NULL, NULL, '2021-12-07'),
	(14, 4, 'Quibusdam iusto.', 1, NULL, NULL, '2021-12-07'),
	(15, 4, 'Animi dolores.', -1, NULL, NULL, '2021-12-07'),
	(16, 5, 'Qui quo atque.', -1, NULL, NULL, '2021-12-07'),
	(17, 3, 'Natus incidunt quia.', 1, NULL, NULL, '2021-12-07'),
	(18, 3, 'Et eos est ut rerum.', 1, NULL, NULL, '2021-12-07'),
	(19, 4, 'Incidunt.', 1, NULL, NULL, '2021-12-07'),
	(20, 4, 'Fugit iste.', 1, NULL, NULL, '2021-12-07'),
	(21, 2, 'sdgasdgsadgasdg', 1, 'dokumen/hCloc8qriTVubGOtqLWTY8PxScR58fkGsA63d3av.pdf', 'anjayyyrturt', '2021-12-07'),
	(22, 5, 'Testing Upload', 1, 'dokumen/djpk1SjvYj8GvNlt6pK7hQTdjv9OTMylpfQyyqyp.pdf', 'isi komentar', '2021-12-08'),
	(24, 2, 'Evaluasi Program Kerja 1', 0, 'dokumen/GYM53d837FG6LcCQG5InI8emlZTfOk6G859b3RGS.pdf', NULL, '2021-12-08');
/*!40000 ALTER TABLE `evaluasis` ENABLE KEYS */;

-- Dumping structure for table siekihproker.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table siekihproker.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping structure for table siekihproker.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table siekihproker.migrations: ~5 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2014_10_12_100000_create_password_resets_table', 1),
	(3, '2019_08_19_000000_create_failed_jobs_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2021_12_04_091720_create_evaluasis_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table siekihproker.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table siekihproker.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table siekihproker.personal_access_tokens
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table siekihproker.personal_access_tokens: ~0 rows (approximately)
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Dumping structure for table siekihproker.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jabatan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isAdmin` tinyint(1) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table siekihproker.users: ~5 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `username`, `nama`, `jabatan`, `password`, `isAdmin`, `remember_token`) VALUES
	(1, 'admin', 'Dr. Umi Laili Yuhana S.Kom., M.Sc.', 'Sekretaris Institut', '$2y$10$Ub/fhjIT8bb/sys7uKJ4X.QxgH5M/g7Xw8zIie.Vq1y1rYdZjEsHi', 1, NULL),
	(2, 'user1', 'Ahmad', 'Kepala Unit Pengelolaan dan Pengendalian Program', '$2y$10$kbUsUW2kEZTFhKzOIvHsN.hwDwVAT0B9B3FbCQlZYxIAt8WxrFv5a', 0, NULL),
	(3, 'user2', 'Budi', 'Kepala Unit Komunikasi Publik', '$2y$10$z3RZs2Bb92sGH3ZMM9WdAuy6vLXlDzMrfsye/BBUXoEcfMDeSOHB6', 0, NULL),
	(4, 'user3', 'Ilham', 'Kepala Unit Layanan Hukum dan Pengelolaan Risiko', '$2y$10$E8Bu/nRW.NpUjVasw/DFk.8clCPfaL2UdB5EzwaqdqwTOI5J6HZ3S', 0, NULL),
	(5, 'user4', 'Kurniawan', 'Kepala Subbagian Administrasi Sekretaris Institut', '$2y$10$wYKUkvINrWwF0FuvvwQv/uUqSE8kXD2ckJJpOR35KJCVELl5RqiWS', 0, NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
